import { LOADER } from "../Actions/ActionTypes";

export default (state = false, action = {}) => {
  if (action.type === LOADER) {
    return action.data;
  }
  return state;
};
