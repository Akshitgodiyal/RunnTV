import axios from "axios";
import { refreshTokenAPI } from "../api/api";

// import { persistor } from "../Store/store.js";

// import { useDispatch } from "react-redux";
// import { resetState } from "../Store/Slices/userSlice.js";
// import { store } from "../Store/store.js";
let refreshingToken = null;

const instance = axios.create({
    baseURL: process.env.REACT_APP_REFRESHTOKEN_URL,
    withCredentials: true,
});


const refreshTokens = () => instance.post(`auth/refresh`);

// console.log("refreshTokens", instance.get(`auth/refresh`) , process.env.REACT_APP_REFRESHTOKEN_URL);
instance.interceptors.request.use((config) => {
    // don't need to send cookies for sign_in API
    //   if (config.url === "auth/signin") {
    //     return config;
    //   }
    config.data =
    {
        "refreshToken": localStorage.getItem("refreshToken")
    }
    config.headers["Authorization"] = `Bearer ${localStorage.getItem("accessToken")}`;
    
    return config;
});

const maxRetryAttempts = 1;
let attemts = 0;

instance.interceptors.response.use(
    function (response) {
        if (response.config.url === "auth/refresh") {
            localStorage.setItem("accessToken", response.data.accessToken);
        }
        return response;
    },
    async function (error) {
        const config = error.config;

        if (error.response && error.response.status === 401 && error.response.data.message == "Access token expired" && !config._retry) {
            console.log("asaasas");
            // 


            // let timer;
            // console.log("Sas", error.response.data.message);

            // if (maxRetryAttempts >= attemts) {
            //     attemts += 1;
            //     // Create a new promise that retries the request after a delay
            //     return new Promise((resolve) => {
            //         console.log("hiii dalru");
            //         timer = setInterval(() => resolve(instance(config)), timer); // Retry after 1 second

            //     });
            // } else {
            //     clearInterval(timer);
            // }
            const intervalID = setInterval(function () {
                attemts++; if (attemts > maxRetryAttempts) {
                    clearInterval(intervalID);
                    console.log("Interval cleared. Max attempts reached.");
                  
                }
                else {
                    console.log(`Attempt ${attemts}`);
                    refreshTokenAPI();
                }
            }, 1000);



            // refreshingToken = refreshingToken ? refreshingToken : refreshTokens();
            // await refreshingToken;
            // refreshingToken = null;
            // try {
            //     refreshingToken = refreshingToken ? refreshingToken : refreshTokens();
            //     await refreshingToken;
            //     refreshingToken = null;

            //     return instance(config);
            //   } catch (error) {
            //     return Promise.reject(error);
            //   }


        } else if (error.response.status === 401 && error.response.data.message == "refresh token expire") {
            localStorage.clear();
            window.location.href = "/";
            // persistor();
            // persistor.purge().then(() => {});
            // const dispatch = useDispatch();
            // dispatch(resetState);
            // store.dispatch(resetState);
        }
        return Promise.reject(error);
    }
);
// const refreshTokenAPI = async () => {
//     let URL = `${process.env.REACT_APP_REFRESHTOKEN_URL}/auth/refresh`;
//     // console.log("drgdfg",URL);
//     const data = {
//         "refreshToken": localStorage.getItem("refreshToken")
//     }



//     axios.get(URL, data, {
//         headers: {
//             "Access-Control-Allow-Origin": "*",

//         }
//     }).then((response) => {

//         console.log("SAas", response.data?.data?.accessToken);
//         localStorage.setItem("accessToken", response.data?.data?.accessToken);

//         // callerrorbox();
//         // seterrormsg(response.data.response.error.message);
//         // ApiHelper.SendGAException(response.data.response.error.message);
//         // setErrors({
//         //   ...errors,
//         //   username: 'wrong password',
//         // });

//     });
// };



export default instance;