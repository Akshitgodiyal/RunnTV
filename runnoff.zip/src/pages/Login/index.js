import React, { useState } from 'react';
import "../../assets/css/style.scss"
import LoginHeader from '../../component/Login-header'
import welcome from "../../assets/images/login-bg.png"
import realtv from "../../assets/images/real-tv.png"
import lock_outline from "../../assets/images/lock_outline.svg"
import mail_outline from "../../assets/images/mail_outline.svg"
import hide_text from "../../assets/images/hide-text.png"
import axios from "axios";
import instance from "../../service/axiosConfig";
import { profileApi } from '../../api/api';


export default function Login() {

  //validations
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const isEmailValid = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailRegex.test(email);
  };

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    // Real-time validation for email
    if (name === 'username') {
      if (value && !isEmailValid(value)) {
        setErrors({
          ...errors,
          username: 'Invalid email format',
        });
      } else {
        setErrors({
          ...errors,
          username: '',
        });
      }
    }

    // Real-time validation for password
    if (name === 'password') {
      const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
      if (!passwordRegex.test(value)) {
        setErrors({
          ...errors,
          password: 'Password must be at least 8 characters, contain at least one letter, and one symbol (@$!%*#?&)',
        });
      } else {
        setErrors({
          ...errors,
          password: '',
        });
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();


    if (rememberMe) {
      // Store a token or set a cookie for "Remember Me" functionality
      // You can use localStorage or sessionStorage for this purpose
      // For example:
      localStorage.setItem('rememberMeToken', 'your_token_value');
    }

    // Your form submission logic here
  };

  const isSubmitDisabled = errors.username || errors.password || !formData.username || !formData.password;
  const [showPassword, setShowPassword] = useState(false);

  const handleMouseDown = () => {
    setShowPassword(true);
  };

  const handleMouseUp = () => {
    setShowPassword(false);
  };
  const [rememberMe, setRememberMe] = useState(false);

  //login api 
  const LoginAPI = async () => {
    let URL = `${process.env.REACT_APP_LOGIN_URL}`;
    // console.log("drgdfg",URL);
    const data = {
      "email": formData.username,
      "password": formData.password,
      "deviceInfo": {
        "deviceId": "string",
        "deviceType": "DEVICE_TYPE_WEB",
        // "notificationToken": "string"
      }
    };

    axios.post(URL, data, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "ngrok-skip-browser-warning": true
      }
    }).then((response) => {
      if (response.status == 200 && response.data.success == true) {

        // console.log("sa",response?.data?.data ,response.data.success);
        localStorage.setItem("accessToken", response.data?.data?.accessToken);
        localStorage.setItem("refreshToken", response.data?.data?.refreshToken);

        // localStorage.setItem(
        //   "profileData",
        //   JSON.stringify(response.data.response.customer)
        // );

      } else {
        // callerrorbox();
        // seterrormsg(response.data.response.error.message);
        // ApiHelper.SendGAException(response.data.response.error.message);
        setErrors({
          ...errors,
          username: 'wrong password',
        });

      }
    });
  };

  //refresh token
  const RefreshingToken = async () => {
    let URL = `${process.env.REACT_APP_REFRESHTOKEN_URL}`;
    // console.log("drgdfg",URL);
    const data = {
      "refreshToken": "string"
    }

    axios.post(URL, data, {
      headers: {
        "Access-Control-Allow-Origin": "*",

      }
    }).then((response) => {
      if (response.status == 200 && response.data.success == true) {

        // console.log("sa",response?.data?.data ,response.data.success);
        localStorage.setItem("accessToken", response.data?.data?.accessToken);


        // localStorage.setItem(
        //   "profileData",
        //   JSON.stringify(response.data.response.customer)
        // );

      } else {
        // callerrorbox();
        // seterrormsg(response.data.response.error.message);
        // ApiHelper.SendGAException(response.data.response.error.message);
        setErrors({
          ...errors,
          username: 'wrong password',
        });

      }
    });
  };

  //profile api

  // const Profile = async () => {
  //   let URL = `${process.env.REACT_APP_REFRESHTOKEN_URL}user/me`;

  //   // const data = {
  //   //   "refreshToken": "string"
  //   // }
  //   let accessToken = localStorage.getItem("accessToken");
  //   console.log("data");
  //     console.log("inside try bblock");
  //     instance.get(URL, {
  //       headers: {
  //         "Access-Control-Allow-Origin": "*",
  //         // "ngrok-skip-browser-warning": true
  //       }
  //     })
  //     .then((response) => {
  //       if (response.status == 200 && response.data.success == true) {

  //         // console.log("sa",response?.data?.data ,response.data.success);
  //         // localStorage.setItem("accessToken", response.data?.data?.accessToken);


  //         // localStorage.setItem(
  //         //   "profileData",
  //         //   JSON.stringify(response.data.response.customer)
  //         // );

  //       } else {
  //         // callerrorbox();
  //         // seterrormsg(response.data.response.error.message);
  //         // ApiHelper.SendGAException(response.data.response.error.message);
  //         // setErrors({
  //         //   ...errors,
  //         //   username: 'wrong password',
  //         // });
  //       }
  //     })
      


  // };

  const hello = async () => {
    await profileApi();
  }





  console.log("errors", errors);
  return (
    <>
      <LoginHeader />
      <div className="main">
        <div className="welcome">
          <div className="img">
            <img src={welcome} alt="asfg" />
          </div>
          <div className="welcome-content">
            <img src={realtv} alt="" />
            <h1>Welcome Back!</h1>
            <p>Enter your registered email address and password and continue with us!</p>
          </div>
        </div>
        <div className="login-block">
          <div className="login-form">
            <div className="title">
              <h2>Login</h2>
            </div>
            <form onSubmit={handleSubmit}>
              <div className={errors.username ? "form-group error-msg" : "form-group"}>
                <label className="form-label">Email address</label>
                <div className="input-group input-group-sm">
                  <div className="input-group-prepend">
                    <img src={mail_outline} alt="" />
                  </div>
                  <input
                    name="username"
                    id="username"
                    type="text"
                    placeholder="Enter email address"
                    className="form-control"
                    defaultValue={formData.username}
                    onChange={handleChange}
                  />
                </div>
                {errors.username && <span className="error">{errors.username}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Password</label>
                <div className="input-group input-group-sm">
                  <div className="input-group-prepend">
                    <img src={lock_outline} alt="" />
                  </div>
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter password"
                    className="form-control"
                    defaultValue={formData.password}
                    onChange={handleChange}
                  />
                  <a
                    type='button'
                    onMouseDown={handleMouseDown}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                  >
                    <img style={{ margin: "auto 0px auto 5px" }} src={hide_text} alt="" />
                  </a>
                </div>
                {errors.password && <span className="error">{errors.password}</span>}
              </div>
              <div className="row">
                <div className="col-sm-6">
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" value="" id="flexCheckChecked" />
                    <label className="form-check-label" htmlFor="flexCheckChecked">
                      Remember me
                    </label>
                  </div>
                </div>
                <div className="col-sm-6 text-right">



                  <a className="forgot" href='/forget-password'>Forgot password?</a>
                </div>
              </div>
              <button onClick={() => LoginAPI()} disabled={isSubmitDisabled} className="btn btn-block">Login</button>
              <button type="submit" onClick={() => hello()} className="btn btn-block">hello n</button>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}
