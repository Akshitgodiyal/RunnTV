import React, { useState } from 'react';
import "../../assets/css/style.scss"
import LoginHeader from '../../component/Login-header'
import realtv from "../../assets/images/real-tv.png"
import welcome from "../../assets/images/login-bg.png"
import lock_outline from "../../assets/images/lock_outline.svg"

function ResetPassword() {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordsMatch, setPasswordsMatch] = useState(true);
  const [passwordError, setPasswordError] = useState('');

  const handlePasswordChange = (event) => {
    const newPassword = event.target.value;
    setPassword(newPassword);
    validatePassword(newPassword, confirmPassword);
  };

  const handleConfirmPasswordChange = (event) => {
    const newConfirmPassword = event.target.value;
    setConfirmPassword(newConfirmPassword);
    validatePassword(password, newConfirmPassword);
  };

  const validatePassword = (newPassword, newConfirmPassword) => {
    if (newPassword.length < 8 || !/[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/.test(newPassword)) {
      setPasswordError('Password must contain a minimum of 8 characters and at least one symbol e.g. @, !');
    } 
    // else if (!/[a-zA-Z]/.test(newPassword)) {
    //   setPasswordError('Password must contain at least one letter');
    // }
    // else if (!/[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/.test(newPassword)) {
    //   setPasswordError('Password must contain a minimum of 8 characters and at least one symbol e.g. @, !');
    // } 
    else if (newPassword !== newConfirmPassword) {
      setPasswordError('Passwords do not match');
    } else {
      setPasswordError('');
    }
  
    // Check if passwords match when both fields change
    setPasswordsMatch(newPassword === newConfirmPassword);
  };
  

  const handleSubmit = (event) => {
    event.preventDefault();
    if (passwordsMatch) {
      // Submit the form or perform password reset logic here
      console.log('Passwords matched. Submitting form...');
    } else {
      // Handle password mismatch case
      console.error('Passwords do not match. Please try again.');
    }
  };







//   const ResetPasswordAPI = async () => {
//     let URL = `${process.env.REACT_APP_LOGIN_URL}`;
//     // console.log("drgdfg",URL);
//     const data ={
//         "email": "string",
//         "password": password,
//         "confirmPassword": confirmPassword,
//         "token": localStorage.getItem("accessToken")
//       }

//     axios.post(URL, data, {
//       headers: {
//         "Access-Control-Allow-Origin": "*",
//         "ngrok-skip-browser-warning": true
//       }
//     }).then((response) => {
//       if (response.status == 200 && response.data.success == true) {

//         // console.log("sa",response?.data?.data ,response.data.success);
//         localStorage.setItem("accessToken", response.data?.data?.accessToken);
//         localStorage.setItem("refreshToken", response.data?.data?.refreshToken);

//         // localStorage.setItem(
//         //   "profileData",
//         //   JSON.stringify(response.data.response.customer)
//         // );

//       } else {
//         // callerrorbox();
//         // seterrormsg(response.data.response.error.message);
//         // ApiHelper.SendGAException(response.data.response.error.message);
//         setErrors({
//           ...errors,
//           username: 'wrong password',
//         });

//       }
//     });
//   };




  return (
    <>
      <LoginHeader />
      <div class="main">
        <div class="welcome">
          <div class="img">
            <img src={welcome} alt="" />
          </div>
          <div class="welcome-content forget-content">
            <img src={realtv} alt="" />
            <p>With Runn TV, we are bringing the <span>simplicity, fun</span> and <span>comfort</span> of traditional TV viewing on Digital.</p>
          </div>
        </div>
        <div class="login-block">
          <div class="login-form">
            <div class="title">
              <h2>Reset password</h2>
            </div>
            <form onSubmit={handleSubmit}>
              <div class="form-group">
                <label class="form-label">New Password</label>
                <div class="input-group input-group-sm">
                  <div class="input-group-prepend">
                    <img src={lock_outline} alt="" />
                  </div>
                  <input
                    type="password"
                    placeholder="Minimum 8 characters"
                    className="form-control"
                    value={password}
                    onChange={handlePasswordChange}
                  />
                </div>
              </div>
              <div class="form-group error-msg">
                <label class="form-label">Confirm new password</label>
                <div class="input-group input-group-sm">
                  <div class="input-group-prepend">
                    <img src={lock_outline} alt="" />
                  </div>
                  <input
                    type="password"
                    placeholder="Confirm new password"
                    className="form-control"
                    value={confirmPassword}
                    onChange={handleConfirmPasswordChange}
                  />
                </div>
                {passwordError && (
                  <span className="error">{passwordError}</span>
                )}
                {!passwordsMatch && !passwordError && (
                  <span className="error">The passwords do not match. Please try again</span>
                )}
              </div>
              <button type="submit" class="btn btn-block">Reset password</button>
            </form>
            <div class="retun-block">
              <p>Return to <a>Login !</a></p>
              {/* <p>Return to <a [routerLink]="['/']">Login !</a></p> */}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default ResetPassword
