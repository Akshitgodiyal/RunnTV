import React from 'react'
import "./vieweship.scss"
import content_icon from "../../assets/images/content-icon.svg"
import live_tv from "../../assets/images/live_tv.svg"
import room from "../../assets/images/room.svg"
import down_arrow from "../../assets/images/down-arrow.svg"
import filter_alt from "../../assets/images/filter_alt.svg"
import ActiveUser from '../../component/active-user'
import DashboardHeader from '../../component/dashboard-header'





function Viewership() {
  return (
    <><DashboardHeader />
<div className="deshboard-content">
  <div className="title">
    <h2>Viewership </h2>
  </div>
  <div className="view-duration">
    <div className="view-block">
      <h5>View by </h5>
      <div className="radio-list">
        <div className='radio-box'>
          <input id='content' value="Content" name="view_by" type="radio" />
          <label for='content'><img src={content_icon}/>Content</label>
        </div> 
        <div className='radio-box'>
          <input id='Genre' value="Genre" name="view_by" type="radio" />
          <label for='Genre'><img src={live_tv}/>Genre</label>
        </div>
        <div className='radio-box'>
          <input id='Location' value="Location" name="view_by" type="radio" />
          <label for='Location'><img src={room}/>Location</label>
        </div>
      </div>
    </div> 
    <div className="duration-block">
      <h5>Duration </h5>
      <div className="radio-list">
        <div className='radio-box'>
          <input id='Today' value="Today" name="Duration" type="radio" />
          <label for='Today'>Today</label>
        </div> 
        <div className='radio-box'>
          <input id='Week' value="Week" name="Duration" type="radio" />
          <label for='Week'>This Week</label>
        </div>
        <div className='radio-box'>
          <input id='Month' value="Month" name="Duration" type="radio" />
          <label for='Month'>This Month</label>
        </div>
        <div className='radio-box'>
          <input id='Year' value="Year" name="Duration" type="radio" />
          <label for='Year'>This Year</label>
        </div>
        <div className='radio-box'>
          <input id='Custom' value="Custom" name="Duration" type="radio" />
          <label for='Custom'>Custom</label>
        </div>
      </div>
    </div>
  </div>
  <div className='channel-container'>
    <div className='channel-table'>
      <div className="channel-table-header">
        <div className="table-row">
          <div className="table-header-col name">Channel Name</div>
          <div className="table-header-col">Active Users</div>
          <div className="table-header-col">Total Watch Hours</div>
          <div className="table-header-col">Avg - Watch Time Per User<br/><small>(HH:MM:SS)</small></div>
          <div className="table-header-col">Avg - Watch Time Per Session <br/><small>(HH:MM:SS)</small></div>
          <div className="table-header-col">Total Ad Impression</div>
        </div>
      </div>
      <div className="channel-table-body">
        <div className="channel-accordion">
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'>
                      <img src={filter_alt}/>
                    </a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div> 
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                    <div className="filter-drodown">
                      <a className="close" href="#">Account</a> 
                      <div className='filter-content'>
                        <div className='select-box'>
                          <label>Show </label>
                          <select>
                            <option>Top 10</option>
                            <option>Top 20</option>
                            <option>Top 30</option>
                          </select>
                        </div>
                        <div className='select-box'>
                          <label>Sort By  </label>
                          <select>
                            <option>Active Users</option>
                            <option>InActive Users</option> 
                          </select>
                        </div>
                        <div className='btn-block'>
                          <a href='' className='btn-clear'>Clear</a>
                          <a href=''className='btn'>Apply</a>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>
          <div className='accordion-block'>
            <a className="toggle" href="!#">
              <div className="table-row">
                <div className="table-col name">
                  <div className='icon'><img src={down_arrow}/></div>
                  <span>Kids</span>
                  <div className="filter-block">
                    <a href='#' className='filter-icon'><img src={filter_alt}/></a>
                  </div>
                </div>
                <div className="table-col">2345</div>
                <div className="table-col">5.5 Hrs</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">05:35:03</div>
                <div className="table-col">2345</div>
              </div>
            </a>
            <div className="inner">
                <div className='info'>
                  Showing Top 10 Content by Active Users this week
                </div>
                <div className='table-content'>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                  <div className="table-row">
                    <div className="table-col name">Show Name</div>
                    <div className="table-col">2345</div>
                    <div className="table-col">5.5 Hrs</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">05:35:03</div>
                    <div className="table-col">567</div>
                  </div>
                </div>
            </div>
          </div>   
        </div>
      </div>
    </div>
    <div className='active-user-section'>
     <ActiveUser />
    </div>
  </div>  
</div>
</>
  )
}

export default Viewership