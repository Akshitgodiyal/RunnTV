import React from 'react'
import "./DashboardHeader.scss"
import person from "../../assets/images/person.svg"
import help_outline from "../../assets/images/help_outline.svg"
import call from "../../assets/images/call.svg"
import info from "../../assets/images/info.svg"
import power_settings_new from "../../assets/images/power_settings_new.svg"
import logo from "../../assets/images/logo.png"

export default function DashboardHeader() {
  return (
<div class="deshboard-header">
    <div class="left-side">
        <div class="logo">
          <a href="#">
            <img src={logo} alt="" />
          </a>
        </div>
        <div class="welcome-name">
          <h5>Welcome back, Manish Sinha</h5>
          <div class="date">
            <span>Monday, 20th March 2023</span>
          </div>
        </div>
      </div>
      <div class="right-side">
        <div class="user">
          <div class="user-dropdown">
            {/* <a class='box' (click)="userDropdown()" [ngClass]="userActive ? 'active' : 'no-active'"> */}
            <a class='box'  >
              <div class="name">
                M
              </div>
            </a>
            <div class='dropdown'  > 
                <a class='close'  >Account</a>
                <ul>
                  <li><a href=''><img src={person} />My Profile</a></li>
                  <li><a href=''><img src={help_outline} />Need Help?</a></li>
                  <li><a href=''><img src={call} />Contact Us</a></li>
                  <li><a href=''><img src={info} />More Info</a></li>
                  <li><a href=''><img src={power_settings_new} />Logout</a></li>
                </ul> 
            </div>
          </div>
        </div>
      </div>
</div>
  )
}
