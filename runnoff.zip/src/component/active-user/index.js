import React from 'react'
import "./activeUser.scss"

import plusicon from '../../assets/images/plus-icon.png'
import minusicon from '../../assets/images/minus-icon.png'
import indiamap from '../../assets/images/india-map.png'



function ActiveUser() {
  return (
<>

    <div class='active-user-block'>
      <div class="top">
        <div class="left-side">
          <h4>Active Users</h4>
          <p>Kids - Channel Name</p>
        </div> 
        <div class="zoom-map">
          <a href="#" class='pulse'><img src={plusicon} alt=''/></a>
          <a href="#" class='minus'><img src={minusicon} alt=''/></a>
        </div>
      </div>
      <div class="map-block">
        <img src={indiamap} alt=''/>
      </div>    
      <div class='top-state'>
        <h6>Top 6 States Users</h6>
        <ul>
          <li><span>Uttar Pradesh</span><span>38K</span></li>
          <li><span>Tamil Nadu</span><span>38K</span></li>
          <li><span>Maharashtra</span><span>10K</span></li>
          <li><span>Karnataka</span><span>10K</span></li>
          <li><span>Haryana</span><span>44K</span></li>
          <li><span>Rajasthan</span><span>44K</span></li>
        </ul>
      </div>
    </div> 
    </>
  )
}

export default ActiveUser