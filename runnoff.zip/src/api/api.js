import axios from "axios";
const refreshToken = localStorage.getItem("refreshToken")

export const refreshTokenAPI = async () => {
    let URL = `${process.env.REACT_APP_REFRESHTOKEN_URL}auth/refresh`;

    const data = {
        "refreshToken": refreshToken
    }
    try {
        const { data: { success, data: { accessToken }
        } } = await axios.post(URL, data, {
            headers: {
                "Access-Control-Allow-Origin": "*",
            }
        });

        console.log("acc", accessToken);
        if (success) {
            // localStorage.setItem("accessToken", accessToken)
            await profileApi();
        }

        // let status = true;
        // if (status) {
        //     alert("refresh api success");
        //     
        // }

    } catch (err) {
        console.log("res error", err);
        const { response: { data: { message } } } = err;
        if (message == "Refresh token expired") {
            // window.location.href = "/"
        }
    }

};


export const profileApi = async () => {
    let URL = `${process.env.REACT_APP_REFRESHTOKEN_URL}user/me`;
    let maxRetryAttempts = 2;
    let attemts = 0;
    try {
        await axios.get(URL, {
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Authorization": `Bearer ${localStorage.getItem("accessToken")}`
            }
        })
    } catch (err) {
        console.log(err);
        const { response: { data: { message } } } = err;
        if (message === "Access token expired") {
            console.log("hii");
            //     const intervalID = setInterval(function () {
            //         attemts++; if (attemts > maxRetryAttempts) {
            //             clearInterval(intervalID);
            //             console.log("Interval cleared. Max attempts reached.");

            //         }
            //         else {
            //             console.log(`Attempt ${attemts}`);
            await refreshTokenAPI();
            //         }
            //     }, 1000);
        }
    }


};